#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include "timer.h"          // Timer library for AVR-GCC
#include <twi.h>            // I2C/TWI library for AVR-GCC
#include <oled.h>
#include <stdlib.h>         // C library. Needed for number conversions

#define DHT_ADR 0x5c
#define DHT_HUM_MEM 0
#define DHT_TEMP_MEM 2

volatile uint8_t update_oled = 0;
volatile uint8_t dht12_values[5];

void uart_init(uint16_t ubrr) {
    // Set baud rate
    UBRR0H = (uint8_t)(ubrr >> 8);
    UBRR0L = (uint8_t)ubrr;
    // Enable transmitter
    UCSR0B = (1 << TXEN0);
    // Set frame format: 8 data bits, 1 stop bit
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void uart_transmit(uint8_t data) {
    // Wait for empty transmit buffer
    while (!(UCSR0A & (1 << UDRE0)));
    // Put data into buffer, sends the data
    UDR0 = data;
}

void uart_print_string(const char *str) {
    while (*str) {
        uart_transmit(*str++);
    }
}

int main(void)
{
    char string[2];  // String for converting numbers by itoa()

    // Initialize UART with baud rate 9600 for 16 MHz clock
    uart_init(103);

    twi_init();

    // Init OLED
    oled_init(OLED_DISP_ON);
    oled_clrscr();

    oled_charMode(DOUBLESIZE);
    oled_puts("OLED disp.");

    oled_charMode(NORMALSIZE);

    oled_gotoxy(0, 2);
    oled_puts("128x64, SH1106");

    oled_drawLine(0, 25, 120, 25, WHITE);

    oled_gotoxy(0, 4);
    oled_puts("AVR course, Brno");

    oled_gotoxy(0, 6);
    oled_puts("Temperature [C]:");
    oled_gotoxy(0, 7);
    oled_puts("Humidity    [\%]:");

    oled_display();

    ADMUX = ADMUX | (1<<REFS0);  // Select ADC voltage reference
    ADMUX = ADMUX & ~(1<<MUX3 | 1<<MUX2 | 1<<MUX1 | 1<<MUX0); // ADC0 channel
    ADCSRA = ADCSRA | (1<<ADEN);  // Enable ADC
    ADCSRA = ADCSRA | (1<<ADIE);  // Enable conversion complete interrupt
    ADCSRA = ADCSRA | (1<<ADPS2 | 1<<ADPS1 | 1<<ADPS0);  // Prescaler 128

    TIM1_ovf_1sec();
    TIM1_ovf_enable();

    sei();

    while (1)
    {
        if (update_oled == 1)
        {
            oled_gotoxy(17, 6);
            oled_puts("    ");
            oled_gotoxy(17, 6);
            itoa(dht12_values[2], string, 10);
            oled_puts(string);
            oled_puts(".");
            itoa(dht12_values[3], string, 10);
            oled_puts(string);

            oled_gotoxy(17, 7);
            oled_puts("    ");
            oled_gotoxy(17, 7);
            itoa(dht12_values[0], string, 10);
            oled_puts(string);
            oled_puts(".");
            itoa(dht12_values[1], string, 10);
            oled_puts(string);

            oled_display();

            update_oled = 0;
        }
    }

    return 0;
}

// Timer1 overflow interrupt
ISR(TIMER1_OVF_vect)
{
    static uint8_t n_ovfs = 0;

    // Start ADC conversion
    ADCSRA = ADCSRA | (1<<ADSC);

    n_ovfs++;
    if (n_ovfs >= 5)
    {
        n_ovfs = 0;

        // Test ACK from Temp/Humid sensor
        twi_start();
        if (twi_write((DHT_ADR<<1) | TWI_WRITE) == 0) {
            twi_write(DHT_HUM_MEM);
            twi_stop();
            twi_start();
            twi_write((DHT_ADR<<1) | TWI_READ);
            dht12_values[0] = twi_read(TWI_ACK);
            dht12_values[1] = twi_read(TWI_ACK);
            dht12_values[2] = twi_read(TWI_ACK);
            dht12_values[3] = twi_read(TWI_NACK);

            update_oled = 1;
        }
        twi_stop();
    }
}

// ADC conversion complete interrupt
ISR(ADC_vect)
{
    uint16_t adc_value = ADC;  // Read ADC value (10 bits)
    char buffer[10];
    itoa(adc_value, buffer, 10);
    uart_print_string("ADC Value: ");
    uart_print_string(buffer);
    uart_print_string("\r\n");
}
